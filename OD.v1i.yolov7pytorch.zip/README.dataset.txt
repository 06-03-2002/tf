# OD > 2024-06-14 1:18am
https://universe.roboflow.com/deep-learning-itqgc/od-0omzx

Provided by a Roboflow user
License: CC BY 4.0

